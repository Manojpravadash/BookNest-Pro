function sendMessage() {
let input = document.getElementById("userInput").value.trim();
if (!input) return;
addMessage(input, "user");
recommendBook(input.toLowerCase());
document.getElementById("userInput").value = "";
}

function addMessage(text, sender) {
let chat = document.getElementById("chatBox");
let msg = document.createElement("div");
msg.classList.add("message", sender);
msg.innerText = text;
chat.appendChild(msg);
chat.scrollTop = chat.scrollHeight;
}

function recommendBook(query) {
let matchedBooks = books.filter(book =>
book.keywords.some(k => query.includes(k)) || query.includes(book.genre)
);

if (matchedBooks.length > 0) {
let suggestions = matchedBooks.map(b => "• " + b.title).join("\n");
addMessage("Here are some books you might like:\n" + suggestions, "bot");
} else {
addMessage("I couldn’t find an exact match, but try asking by genre like 'fiction', 'self-help', or 'programming'.", "bot");
}
}
