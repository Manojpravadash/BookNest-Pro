const books = [
{ title: "Atomic Habits", genre: "self-help", keywords: ["habit", "self improvement", "motivation"] },
{ title: "The Alchemist", genre: "fiction", keywords: ["dreams", "journey", "life"] },
{ title: "Clean Code", genre: "programming", keywords: ["coding", "software", "best practices"] },
{ title: "1984", genre: "dystopian", keywords: ["government", "control", "future"] },
{ title: "The Psychology of Money", genre: "finance", keywords: ["money", "wealth", "behavior"] }
];
