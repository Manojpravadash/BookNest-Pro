# 📚 BookNest Pro – Smart Book Recommendation Assistant

BookNest Pro is a lightweight AI-inspired book recommendation website that suggests books based on keywords, genres, and user queries.

### ⭐ Features
- Smart keyword-based recommendations  
- Clean chat-style UI  
- Modular JS structure for easy upgrades  
- Ready for future NLP & API integration  

### 🛠 Tech Used
HTML, CSS, JavaScript

### 🚀 How to Run
Just open `index.html` in your browser.

### 🤝 Contributions
Feel free to enhance recommendation logic or add a backend!
